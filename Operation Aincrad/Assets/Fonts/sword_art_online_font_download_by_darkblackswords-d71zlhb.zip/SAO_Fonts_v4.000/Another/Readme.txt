This "Another" version is very similar to Anime SAO.
But this version doesn't have many letters so far.